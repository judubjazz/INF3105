#line 100
#include <iostream>

int add( int x, int y) {
return x + y;
}
#line 0
int main() {
cout << add( 5, 4 );
return 0;
}
