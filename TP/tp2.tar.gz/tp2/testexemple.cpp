#include <iostream>

int add( int x, int y) {
return x + y;
}

int main() {
cout << add( 5, 4 );
return 0;
}